
function [ params , trialinit , draw , checksum , trialclose ] = gabors
% 
% [ params , trialinit , draw , trialclose ] = gabors
% 
% Defines a gabor stimulus that provides all of the information that is
% required by taskcontroller.m to draw one or more identical gabor stimuli
% on screen.
% 
% 
% Output
% 
% params - one element struct - A default parameter set for the stimulus.
%   Each field names a different parameter, and points to the parameter's
%   value.
% 
% trialinit - function handle, trialinit( params , pardur , ptbwin )
%   Function is executed in preparation for each new trial. It returns a
%   stimulus trial descriptor that the drawing function will use. The
%   stimulus trial descriptor must have at least one field called .hitbox ;
%   this will be an 4 x M matrix of on-screen vertices (row order) for
%   each presented object (column order) describing the area that the
%   subject can hit.
%   
%   Three input arguments are required. params will be converted into the
%   stimulus trial descriptor, taking into account the screen parameters
%   provided by ptbwin.
%   
%   ptbwin.ptr - scalar number - PTB window pointer, as returned by
%     Screen( 'OpenWindow' )
%   ptbwin.origin - 2 element numerical vector - The origin in degrees from
%     the top left of the monitor. 
%   ptbwin.pixperdeg - numerical scalar - The number of pixels per degree
%     of visual angle. 
%   ptbwin.flipinterval - numerical scalar - The number of seconds between
%     successive screen refreshes, like the estimate provided by PTB-3
%     Screen( 'GetFlipInterval' , ... ).
%   ptbwin.background - 3 element vector, the RGB value of the window's
%     background.
%   
%   params must be a struct array of one or more elements. Multiple
%   parameter sets can be given to the same stimulus if the block
%   definition's task to concrete stimulus mapping says so. This allows the
%   same stimulus to respond to changes in task state. Consequently, it is
%   necessary to know the timeout associated with each parameter set. This
%   is given in pardur, an N by 2 matrix indexing columns by [ parameter
%   set index , state timeout ] and rows by each pairing. Thus,
%   pardur( i , 1 ) names the parameter set in params, and pardur( i , 2 )
%   says the associated state timeout.
%   
% 
% draw - function handle, draw( f , t , flip , stimtd, p ) - Drawing
%   function that is executed before each frame in which the stimulus is
%   presented. The function will return an updated stimulus trial
%   descriptor. Four input arguments are required. The frame number for
%   the next frame presentation. The duration from a time-zero flip and the
%   most recent frame, in seconds. The flip interval, in seconds. The
%   latest stimulus trial descriptor, initially returned by trialinit. The
%   parameter set index to use for drawing.
%   
%   NOTE: The taskcontroller must know the vbl for all frames generated.
%   ifi is expected between each frame. The vbl of successive frames is f1
%   and f2. ifi - ( f2 - f1 ) + ifi = 2 * ifi - f2 + f1 
% 
% checksum - function handle, checksum( stimtd ) - Adds together any
%   randomly generated components of stimtd into a checksum. This should be
%   done before and after the trial. If the pseudo-random number sequence
%   is successfully replicated, then the checksums will also be.
% 
% trialclose - function handle, trialclose( stimtd ) - Frees any resources
%   that were requested by trialinit. For example, textures are freed using
%   Screen( 'close' , textureIndeces ).
% 
% 
% Stimulus parameters - The parameters represented in params.
% 
%   N - The number of gabors to replicate.
%   
%   alpha - The tranparency level of the gabors, ranges from 0 (tranparent)
%     to 1 (opaque).
%   
%   positset - A set of stimulus positions relative to a point of
%     origin. This is an M x 2 matrix where each row describes one point,
%     the center of the gabor. Given in degrees of visual field.
%
%   posit - A scalar indexing the row of positionset. If zero, then acts as
%     though posit is 1.
%   
%   negposit - A scalar indicating how to interpret posit. If zero,
%     then the first gabor is guaranteed to be placed at the specified
%     position. If nonzero, then the specified position is not used. All
%     other positions are provided in sequence.
%   
%   maxsigma - The maximum posible standard deviation of the gaussian mask,
%     in degrees of visual field.
%   
%   orient - The orientation of the gabor i.e. the rotation about its
%     central point. In degrees, 0 and 180 provide horizontally aligned
%     gabors, while 90 and 270 provide vertical.
%   
%   phase - The starting phase of the sinusoidal component.
%   
%   freq - The starting frequency of the sinusoidal component. In degrees
%     of visual field per cycle.
%   
%   sigma - The starting gaussian standard deviation. In degrees of visual
%     field.
%   
%   contrast - The starting contrast of the sinusoidal component.
%   
%   dpos - Rate of change of position, this is a 2 element vector.
%   
%   dorient - Rate of change of orientation in degrees per second.
%   
%   dphase - Rate of change in phase, in degrees of visual field per
%     second.
%   
%   dfreq - Rate of change in freq, in degrees of visual field per cycle
%     per second.
%   
%     NOTE: The geometry is wrong for this, so the actual rate of change is
%     non-linear.
%   
%   dsig - Rate of change in sigma, in degrees of visual field per second.
%   
%   dcon - Rate of change in contrast value per second.
%   
%   NOTE: d<par> rates of change may be positive or negative.
%   
% 
% Written by Jackson Smith - Oct 2015 - DPAG, University of Oxford
% 
  

  %%% Build params %%%

  % position set
  pxy = sqrt ( 6.5 ^ 2 / 2 ) ;
  positset = [ +pxy , -pxy ;
               -pxy , -pxy ;
               -pxy , +pxy ;
               +pxy , +pxy ] ;

  % Parameter names and values, listed in a cell array for convenience.
  % Note the transposition, this is key for making the struct.
  params = {        'N' , 4 ;
                'alpha' , 1 ;
             'positset' , positset ;
                'posit' , 0 ;
             'negposit' , 0 ;
             'maxsigma' , 2.5 ;
               'orient' , 0 ;
                'phase' , 0 ;
                 'freq' , 1 ;
                'sigma' , 1.25 ;
             'contrast' , 1 ;
                 'dpos' , [ 0 , 0 ] ;
              'dorient' , 0 ;
               'dphase' , 0 ;
                'dfreq' , 0 ;
                 'dsig' , 0 ;
                 'dcon' , 0 }' ;

  % Repackage parameters into a struct.
  params = struct( params{ : } ) ;
  
  
  %%% Trial initialisation function %%%
  
  trialinit = @ftrialinit ;
  
  
  %%% Drawing function %%%
  
  draw = @fdraw ;
  
  
  %%% Checksum function %%%
  checksum = @fchecksum ;
  
  
  %%% Trial close function %%%
  
  trialclose = @ftrialclose ;
  
  
end % gabors


%%% Output functions %%%

function stimtd = ftrialinit( params , ~ , ptbwin )
  
  
  %%% CONSTANTS %%%
  
  % Make radius of support this many times the max standard dev
  msigf = 4 ;
  
  % Make hitbox radius this many standard dev from centre
  hboxf = 1.25 ;
  
  
  %%% Error check ptbwin %%%
  
  % Single element struct?
  if isempty( ptbwin ) || numel( ptbwin ) ~= 1 || ~isstruct( ptbwin )
    error( 'gabors:input:S not valid struct' )
  end
  
  % All required fields are there?
  sF = fieldnames( ptbwin ) ;
  
  % Loop required fields.
  for F = ...
   { 'origin' , 'pixperdeg' , 'flipinterval' , 'background' , 'ptr' }
    
    f = F{1} ;
    
    % Test if there.
    if ~strcmp( f , sF )
      error( 'gabors:input:S lacks field %s' , f )
    end
    
  end
  
  clear sF
  
  
  %%% Convert parameters to usable form, in pixel-based units %%%
  
  % Shorten the name params to p, for ease.
  p = params(1) ;
  
  % Convert degrees to pixels.
  for F = { 'positset' , 'maxsigma' , 'sigma' , 'dpos' , 'dsig' , ...
      'dphase' } , f = F{1} ;
    p.(f) = p.(f) * ptbwin.pixperdeg ;
  end
  
  % Convert posit from 0.
  if ~p.posit
    p.posit = 1 ;
  end
  
  % Convert dphase from degrees of visual field per second to degrees of
  % sinusoid per second.
  % vis.deg/s * pix/vis.deg = pix/s * cycles/pix = cycles/s * 360 deg/cycle
  p.dphase = p.dphase * p.freq * 360 ;
  
  % Do any parameters change over the course of the trial?
  has_d = any( p.dpos ) || ...
    any( [ p.dorient , p.dphase , p.dfreq , p.dsig , p.dcon ] ) ;
 
  % Roll time-varying parameters back by one frame, ready for the first
  % frame with intended starting values.
  if has_d
    
    % Prepare all positions.
    for i = 1:2
      p.positset( : , i ) = p.positset( : , i ) - ...
        ptbwin.flipinterval * p.dpos( i ) ;
    end
    
    % loop varying scalar parameters, prepare them too
    F = { { 'orient' , 'dorient' } , ...
          { 'phase' , 'dphase' } , ...
          { 'freq' , 'dfreq' } , ...
          { 'sigma' , 'dsig' } , ...
          { 'contrast' , 'dcon' } } ;
    
    for P = F , f = P{1} ;
      p.( f{1} ) = p.( f{1} ) - ptbwin.flipinterval * p.( f{2} ) ;
    end
  
  end % has varying parameters
  
  % Wrap around circular values.
  p.orient = mod( p.orient , 360 ) ;
  p.phase = mod( p.phase , 360 ) ;
  
  % Deal with freq values.
  % Convert freq from pixels per cycle to cycles per pixel.
  freq = 1 / ( p.freq * ptbwin.pixperdeg ) ;
  
  
  %%% Check for fatal parameter errors %%%
  
  if size( p.positset , 1 ) < p.N
    error( 'gabors:params:%i positset but %i gabors' , ...
      size( p.positset , 1 ) , p.N )
  elseif p.posit < 0 && size( p.positset , 1 ) == 1
    error( 'gabors:params:no valid position' )
  end
  
  
  %%% Define stimulus trial descriptor %%%
  
  % Gabor positions
  i = 1:size( p.positset , 1 ) ;
  
  if p.negposit
    i = i( [ 1 : p.posit - 1 , p.posit + 1 : end ] ) ;
  else
    i( 1 ) = p.posit ;
    i( p.posit ) = 1 ;
  end
  
  i = i( 1 : p.N ) ;
  gpos = p.positset( i , : ) + repmat( ptbwin.origin , p.N , 1 ) ;
  
  gposrect = zeros( 4 , p.N ) ;
  gposrect( RectRight , : ) = 2 * msigf * p.maxsigma ;
  gposrect( RectBottom , : ) = 2 * msigf * p.maxsigma ;
  
  for i = 1 : p.N
    gposrect( : , i ) = ...
      CenterRectOnPoint( gposrect( : , i )' , gpos(i,1) , gpos(i,2) )' ;
  end
  
  % Hit boxes - Square when aspect ratio is 1 - Change these if oval gabors
  % ever used
  hitbox = zeros( size( gposrect ) ) ;
  hitbox( RectRight  , : ) = ceil( 2 * hboxf * p.maxsigma ) ;
  hitbox( RectBottom , : ) = ceil( 2 * hboxf * p.maxsigma ) ;
  
  for i = 1 : p.N
    hitbox(:,i) = CenterRect( hitbox(:,i)' , gposrect(:,i)' )' ;
  end
  
  
  % Gabor texture parameters.
  % Set with alpha blending in mind. Thus, the screen's background is
  % added. Background offset can be default 0. But the pre-contrast
  % multiplier must be properly set.
  width = ceil( 2 * msigf * p.maxsigma ) ;
  height = width ;
  nonSymmetric = false ;
  backgroundOffset = [] ; %[ ptbwin.background , 0 ] ;
  disableNorm = true ;
  preContrastMultiplier = 0.5 ;
  
  gtex = CreateProceduralGabor( ptbwin.ptr , ...
    width , height , nonSymmetric , backgroundOffset , disableNorm , ...
    preContrastMultiplier ) ;
  
  % Gabor drawing parameters. Must be a matrix with one column per gabor.
  gpar = [ p.phase , freq , p.sigma , p.contrast , 1 , 0 , 0 , 0 ]' ;
  gpar = repmat( gpar , 1 , p.N ) ;
  
  % DrawTextures input
  dti = { ...
      'DrawTextures' ; %  1 - PTB-3 Screen command
          ptbwin.ptr ; %  2 - windowPointer
                gtex ; %  3 - texturePointer
                 [ ] ; %  4 - sourceRect
            gposrect ; %  5 - destinationRect
            p.orient ; %  6 - rotationAngle
                 [ ] ; %  7 - filterMode
             p.alpha ; %  8 - globalAlpha
                 [ ] ; %  9 - modulateColor
                 [ ] ; % 10 - textureShader
kPsychDontDoRotation ; % 11 - specialFlags
                gpar ; % 12 - auxParameters - Gabor texture specific.
                ...
        } ;
  
  % Pack descriptor.
  stimtd.N = p.N ;
  stimtd.Screen_in = dti ;
  stimtd.hitbox = hitbox ;
  stimtd.ppd = ptbwin.pixperdeg ;
  stimtd.freq_dpc = p.freq ; % degrees per cycle, note that p.dfreq is that
  stimtd.has_d = has_d ;
  stimtd.dpos = p.dpos ;
  stimtd.dorient = p.dorient ;
  stimtd.dgab = [ p.dphase , p.dfreq , p.dsig , p.dcon ]' ;
  
end % trialinit


function stimtd = fdraw( ~ , ~ , flip , stimtd , ~ )
  
  
  %%% Update parameters %%%
  
  % Are any parameters variable over time?
  if stimtd.has_d
    
    % Update position rectangles and hitboxes.
    m = 5 ;
    
    i = [ RectLeft , RectRight ] ;
    stimtd.Screen_in{m}(i,:) = ...
      stimtd.Screen_in{m}(i,:) + flip * stimtd.dpos(1) ;
    stimtd.hitbox(i,:) = stimtd.hitbox(i,:) + flip * stimtd.dpos(1) ;
    
    i = [ RectTop , RectBottom ] ;
    stimtd.Screen_in{m}(i,:) = ...
      stimtd.Screen_in{m}(i,:) + flip * stimtd.dpos(2) ;
    stimtd.hitbox(i,:) = stimtd.hitbox(i,:) + flip * stimtd.dpos(2) ;
    
    % Update orientation. Degrees wrap around at 360 to 0.
    m = 6 ;
    stimtd.Screen_in{m} = stimtd.Screen_in{m} + flip * stimtd.dorient ;
    stimtd.Screen_in{m} = mod( stimtd.Screen_in{m} , 360 ) ;
    
    % Update gabor parameters. Degrees wrap around at 360 to 0.
    m = 12 ;
    n = [ 1 , 3 , 4 ] ;
    stimtd.Screen_in{m}(n,:) = stimtd.Screen_in{m}(n,:) + ...
      flip .* repmat( stimtd.dgab(n) , 1 , stimtd.N ) ;
    stimtd.Screen_in{m}(1,:) = mod( stimtd.Screen_in{m}(1,:) , 360 ) ;
    
    % Update frequency.
    n = 2 ;
    stimtd.freq_dpc = stimtd.freq_dpc + flip .* stimtd.dgab(n) ;
    stimtd.Screen_in{m}(n,:) = 1 / ( stimtd.freq_dpc * stimtd.ppd ) ;
    
  end % update params
  
  
  %%% Draw the gabors %%%
  
  % Psych Toolbox environment
  % Enable alpha-blending, set it to a blend equation useable for linear
  % superposition with alpha-weighted source.
  Screen( 'BlendFunction' , stimtd.Screen_in{ 2 } , GL_ONE , GL_ONE) ;
  
  Screen( stimtd.Screen_in{ : } ) ;
  
  
end % fdraw


function s = fchecksum( ~ )
  
  % Unlike random dots, there is no random component to this stimulus.
  % Return zero.
  s = 0 ;
  
end % fchecksum


function ftrialclose( stimtd , ~ )
  
  % Free up the texture memory
  m = 3 ;
  Screen( 'Close' , stimtd.Screen_in{m} ) ;
  
  % Disable alpha blending
%   Screen( 'BlendFunction' , ptbwin.ptr , GL_ONE , GL_ZERO) ;
  
end % ftrialclose

