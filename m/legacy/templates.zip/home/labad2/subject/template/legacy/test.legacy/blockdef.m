
function block = blockdef
% 
% block = blockdef
% 
% Indroduce random-dot kinetograms by mixing them with gabors.
% 
% Block definitions: 3
% 
% Block type 1: Orientation change
%   
%   frequency - The same in all gabors, but randomly selected each trial
%     [0.5 1 2] visual degrees / cycle. 
%   orientation - Differs between target and distractor gabors, but
%     randomly selected each trial [0 45 90 135] degrees
%   contrasts - The same in all gabors, but randomly selected each trial 
%     [ 0.3 , 0.6 , 0.9 ].
%   phase change i.e. drift is same for all gabors, varying between
%     0, 0.2, & 0.4 degrees/second
% 
% Block type 2: Random-dot kinetogram vs gabor distractors
%   
%   Gabors the same as in block 1. RDK target moves slowly enough to keep
%   dots from blurring, motion direction is random, and coherence varies
%   between several levels [ 0.25 , 0.5 , 0.75 , 1 ]
% 
% Block type 3 : Random-dot kinetogram target and distractors
%   
%   All dot patches have identical paramers, except for coherence levels.
%    Target: 0.010 0.025 0.050 0.075 0.100 0.125 0.150 0.200 0.250 0.300 0.350
%Distractors:0.125 0.125 0.125 0.125 0.125 0.125 0.125 0.125 0.125 0.125 0.125
%   D. contrast: 1.000 1.00 1.000 1.00 1.000 1.00 1.00 1.00 1.00 1.00 1.00
%   
%   Target contrast always 1.00
%   
% 
% Output
% 
% block - struct array - Defines the trial block structure, including which
%   stimuli are used and what their parameters are.
% 
% block(i) - the ith block of trials
%   
%   .origins - numerical, 4 element vector or N x 2 matrix - Used to
%     define the stimulus-drawing point of origin within the screen. A
%     different origin will be sampled, for variation in the absolute
%     position of stimuli. If a 4 element vector is given, then it will
%     have the format [ left edge , top edge , right edge , bottom edge ]
%     defining a box in degrees relative to the centre of the screen. Any
%     origin may be sampled from within its bounds. The matrix format
%     provides a list of N points that are randomly sampled, with the
%     column order being [ x position , y position ] in degrees from the
%     centre of the screen.
%     
%     See [ RectLeft , RectTop , RectRight , RectBottom ]
%   
%   .stim_map - struct array, row vector 1 x N - Describes the mapping
%     between each task stimulus and concrete stimulus descriptors. It is
%     required that all index vectors contained therein are sorted
%     ascending.
%   
%     stim_map(j) - Map for the ith task stimulus
%       .con - integer vector - indeces of concrete stimuli that map to the
%         jth abstract task stimulus. Each index may only appear once.
%       .par - The corresponding index for the stimulus's parameter struct
%         array.  Thus stimulus .con(k) uses its .par(k)'th parameter set.
%
%   .task_d - function handle - Returns a task descriptor struct with
%     information about the task and its behaviour.
% 
%   .stim_d - cell array of M elements - Contains stimulus descriptor
%     functions. One per concrete stimulus.
%   .stim_d{j} - function handle - Stimulus descriptor function. Returns
%     default parameters and trial initialiser, drawing, checksum, and
%     closing functions.
%   
%   .stim_par - cell array - contains parameter struct arrays for each
%     stimulus listed in .stim_d.
%   .stim_par{j} - struct array - The parameters for stimulus j, to be used
%     in this block of trials.
%   
%   .stim_var - cell array - one element per concrete stimulus - Describes
%     how to sample variable stimulus parameters from trial to trial.
%   .stim_var{j} - N x 1 struct array - Sampling schedule for jth concrete
%     stimulus. Make this an empty struct of the right kind if there are no
%     variable parameters for a given stimulus.
%   .stim_var{j}(k) - The kth variable parameter of the jth concrete
%     stimulus. Describes if it is sampled independently, or dependently on
%     a reference parameter.
%     
%     .param - string - Names the variable parameter. Must be in the set of
%       parameters from the stimulus descriptor function.
%     .pari - scalar integer - index of stimulus's parameter set.
%     .values - numeric vector - The set of values to sample from.
%     .rule - scalar integer - The sampling rule. 0 sample independently. 1
%       use the same value as the reference. -1 use any value other than
%       what the reference is using. If 0 then the .ref_* fields aren't
%       used and can have any place-holder value.
%     .ref_stim - scalar integer - Index of .stim_par, identifying the
%       reference stimulus containing the reference parameter.
%     .ref_par - string - Names the reference parameter.
%     .ref_pi - scalar integer - index of ref stim's parameter set.
%
%   .stim_schedule - one element struct - Describes hard-wired schedule of
%     parameter values per trial. These are presented in a randomised
%     order. If a trial is ignored, broken, or aborted then the parameters
%     are randomly reshuffled into the deck.
%     
%     .rep - scalar integer - Repetitions of the given schedule deck to
%       present in each block. 
%     .attempts - scalar integer - The number of times a single set of
%       parameters will be reshuffled into the deck following broken
%       trials. Doesn't count for ignored or aborted.
%     .sind - integer vector - N elements, one for each parameter in the
%       schedule. .sind(i) is the ith index that references corresponding
%       elements in .stim_d and .stim_par.
%     .pind - integer vector - N elements, one for each parameter in the
%       schedule. .pind(i) is the ith index that references which stimulus
%       parameters in .stim_par{ .sind(i) } to set. If 0, then the
%       scheduled value is applied to all .stim_par{ .sind(i) }( : ) sets.
%     .params - cell array vector of strings - N elements, names which
%       parameters to set. .params{i} refers to the same stimulus as
%       .sind(i) and .pind(i).
%     .deck - M x N double matrix - The set of scheduled parameter values.
%       Each record (row) describes the parameter values on a single trial.
%       Each field (column) corresponds to an element of .sind, .pind, and
%       .params. For example, .deck( m , n ) describes the value of
%       parameter .params{ n } in parameter set .pind( n ) for concrete
%       stimulus .sind( n ) ; while .deck( m , n + 1 ) describes the value
%       of the next parameter on the same trial.
% 
% 
% Function dependencies: gabors.m , rdk.m , oddoneout.m
% 
% 
% Written by Jackson Smith - Jan 2016 - DPAG, University of Oxford
%
  
  
  %%% CONSTANTS %%%
  
  % Values for defining the sampling rule. IND - independent variable.
  % REF - copy reference parameter's value. NREF - anything but
  % reference's value.
   IND = +0 ;
   REF = +1 ;
  NREF = -1 ;
  
  % Number of block definitions.
  NB = 3 ;
  
  
  %%% Block definitions %%%
  
  %-- Start with lists, package later --%
  
  % The set of on-screen origins to use.
  origins = [ -18 , 6 , 18 , 12 ] ;
  
  % Mapping from concrete gabors stimuli to abstract task stimuli indeces.
  % stim_map{i}, i = 2 is gabor target task stimulus, i = 3 is the
  % random-dot kinetogram target task stimulus, i = 4 is distractor task
  % stimulus. i = 1 is the initial 'fixation' point.
  stim_map_con = { 1 , 2 , 3 , 4 } ;
  stim_map_par = { 1 , 1 , 1 , 1 } ;
  
  % Task definition.
  task_d = @oddoneout ;
  
  % Concrete stimulus definitions. One set for each block.
  stim_d = { { @tdot , @gabors , @gabors , @blankstim } ;
             { @tdot , @rdk    , @gabors , @blankstim } ;
             { @tdot , @rdk    , @rdk    , @blankstim } } ;
  
  
  %-- Any changes to default parameter values --%
  
  % Gabor default parameter changes
  gabdefpar = cell( 2 , 1 ) ;
  
  % Stimulus 1 - Target, only one gabor to show.
  gabdefpar{1} = { 'N' , 1 } ;
  
  % Stimulus 2 - Distractor stimuli, three gabors.
  gabdefpar{2} = { 'N' , 3 ;
                 'negposit' , 1 } ;
               
	% RDK default parameter changes
  rdkdefpar = cell ( 2 , 1 ) ;
  
  % Stim 1 - target, only one dot patch
  rdkdefpar{ 1 } = { 'flast' , 1 } ;
  
  % Stim 2 - target, only one dot patch
  rdkdefpar{ 2 } = { 'ffirst' , 2 } ;
  
  % Default stimulus parameters for square config
  gabor_par_s = gabors ;
  
  % Default tdot parameters for square config
  tdot_par_s = tdot ;
  
  % Default random-dot parameters
  rdk_par = rdk ;
  
  % Blank parameters
  blank_par = blankstim ;
  
  
  %-- Variable parameters --%
  
  % Each record has format: parameter name, par index, values, sampling
  % rule, reference stimulus, reference parameter name, ref par index
  
  % Value distributions
  posit = [ 1 , 2 , 3 , 4 ] ;
  phase = 0 : 45 : 315 ;
  orient = 0 : 45 : 135 ;
  freq = [ 0.5 , 1 , 2 ] ;
  dphase = [ 0.2 , 0.4 ] ;
  direction = 0 : 45 : 315 ;
  coherence = [ 0.25 , 0.5 , 0.75 , 1 ] ;
  frotation = 0 : 45 : 315 ;
  
  % Stimulus 1
  vpar1 = cell( NB , 1 ) ;
  
  % Stimulus 2 - the odd one out
  vpar2 = cell( NB , 1 ) ;
	
	% Block 1 - Gabor target - Dynamic sinusoidal phase
  vpar2{1} = { 'posit' , 1 , posit , IND , 0 , '' , 0 ;
               'phase' , 1 , phase , IND , 0 , '' , 0 ;
               'orient' , 1 , orient , IND , 0 , '' , 0 ;
               'freq' , 1 , freq , IND , 0 , '' , 0 } ;
             
	% Block 2 - RDK target
  vpar2{2} = { 'direction' , 1 , direction , IND , 0 , '' , 0 ;
               'coherence' , 1 , coherence , IND , 0 , '' , 0  } ;
             
  % Block 3 - RDK target
  vpar2{3} = { 'direction' , 1 , direction , IND , 0 , '' , 0 ;
               'frotation' , 1 , frotation , IND , 0 , '' , 0  } ;
	
	% Stimulus 3 - the distractors
  vpar3 = cell( NB , 1 ) ;
	
	% Block 1 - Gabor distractors - Dynamic sinusoidal phase
  vpar3{1} = { 'posit' , 1 , posit , REF , 2 , 'posit' , 1 ;
               'phase' , 1 , phase , REF , 2 , 'phase' , 1 ;
               'orient' , 1 , orient , NREF , 2 , 'orient' , 1 ;
               'freq' , 1 , freq , REF , 2 , 'freq' , 1 } ;

  % Block 2 - Gabor distractor - Dynamic orientation
  vpar3{2} = { 'phase' , 1 , phase , IND , 0 , '' , 0 ;
               'orient' , 1 , orient , IND , 0 , '' , 0 ;
               'freq' , 1 , freq , IND , 0 , '' , 0 ;
               'dphase' , 1 , dphase , IND , 0 , '' , 0 } ;
             
  % Block 3 - RDK distractor
  vpar3{3} = { 'direction' , 1 , direction , REF , 2 , 'direction' , 1 ;
               'frotation' , 1 , frotation , REF , 2 , 'frotation' , 1 } ;

	
	% Stimulus 4
  vpar4 = cell( NB , 1 ) ;
  
  
	%-- Scheduled parameters --%
  
  % Repeat the schedule this many times per block, one element per block
  rep = [ 1 , 1 , 4 ] ;
  
  % The number of times that a broken trial will be reshuffled
  attempts = 3 ;
  
  % Indeces of concrete stimuli whose parameters are scheduled
  sind = { 2 : 3 ;
           2 : 3 ;
           [ 2 , 3 , 3 ] } ;
  
  % The corresponding stimulus parameter sets
  pind = { [ 1 , 1 ] ;
           [ 1 , 1 ] ;
           [ 1 , 1 , 1 ] } ;
  
  % Name the parameters to schedule, one element per block, here.
  params = { {    'dphase' , 'dphase'    } ;   % 1 - diff phase drift
             { 'frotation' , 'posit'     } ;   % 2 - rdk vs gabor
{ 'coherence' , 'coherence' , 'contrast' } } ; % 3 - rdk vs rdk
  
	% The schedule deck, one element per block, here.
  deck = cell( NB , 1 ) ;
    
    % diff phase drift
    deck{ 1 } = [ 0.2 , 0.2 ;
                  0.4 , 0.4 ;
                  0.2 , 0.4 ;
                  0.4 , 0.2 ] ;
    
    % different formation-circle rotations vs gabor positions
    deck{ 2 } = [ 45 , 1 ;
                 135 , 2 ;
                 225 , 3 ;
                 315 , 4 ] ;
               
    % dot motion coherence, coherence & contrast
    deck{ 3 } = [ 0.010 , 0.125 , 1.00 ;
                  0.025 , 0.125 , 1.00 ;
                  0.050 , 0.125 , 1.00 ;
                  0.075 , 0.125 , 1.00 ;
                  0.100 , 0.125 , 1.00 ;
                  0.125 , 0.125 , 1.00 ;
                  0.150 , 0.125 , 1.00 ;
                  0.200 , 0.125 , 1.00 ;
                  0.250 , 0.125 , 1.00 ;
                  0.300 , 0.125 , 1.00 ;
                  0.350 , 0.125 , 1.00 ] ;
  
  
	%-- Pack block definitions into cell arrays --%
  
  % One element per block
  
  origins = repmat( { origins } , NB , 1 ) ;
  stim_map = struct( 'con' , stim_map_con , 'par' , stim_map_par ) ;
  stim_map = repmat( { stim_map } , NB , 1 ) ;
  task_d = repmat( { task_d } , NB , 1 ) ;
  
  gabor_par_s = { gabor_par_s , gabor_par_s } ;
  for i = 1 : numel( gabor_par_s )
    for j = 1 : size( gabdefpar{i} , 1 ) , d = gabdefpar{i}{j,1} ;
      gabor_par_s{ i }.( d ) = gabdefpar{i}{ j , 2 } ;
    end
  end
  
  rdk_par = { rdk_par , rdk_par } ;
  for i = 1 : numel( rdk_par )
    for j = 1 : size( rdkdefpar{i} , 1 ) , d = rdkdefpar{i}{j,1} ;
      rdk_par{ i }.( d ) = rdkdefpar{i}{ j , 2 } ;
    end
  end
  
  stim_par = { [ { tdot_par_s } , gabor_par_s{ : } , { blank_par } ] ;
[ { tdot_par_s } , rdk_par{ 1 } , gabor_par_s{ 2 } , { blank_par } ] ;
               [ { tdot_par_s } , rdk_par{ : } , { blank_par } ] } ;
  
  stim_var = cell( NB , 1 ) ;
  for i = 1 : NB
    vpar1{i} = struct( 'param' , [] , ...
                        'pari' , [] , ...
                      'values' , [] , ...
                        'rule' , [] , ...
                    'ref_stim' , [] , ...
                     'ref_par' , [] , ...
                      'ref_pi' , [] ) ;
    vpar1{i} = vpar1{i}( [] ) ;
    vpar2{i} = struct( 'param' , vpar2{i}(:,1) , ...
                        'pari' , vpar2{i}(:,2) , ...
                      'values' , vpar2{i}(:,3) , ...
                        'rule' , vpar2{i}(:,4) , ...
                    'ref_stim' , vpar2{i}(:,5) , ...
                     'ref_par' , vpar2{i}(:,6) , ...
                      'ref_pi' , vpar2{i}(:,7) ) ;
    
    vpar3{i} = struct( 'param' , vpar3{i}(:,1) , ...
                        'pari' , vpar3{i}(:,2) , ...
                      'values' , vpar3{i}(:,3) , ...
                        'rule' , vpar3{i}(:,4) , ...
                    'ref_stim' , vpar3{i}(:,5) , ...
                     'ref_par' , vpar3{i}(:,6) , ...
                      'ref_pi' , vpar3{i}(:,7) ) ;
    vpar4{i} = struct( 'param' , [] , ...
                        'pari' , [] , ...
                      'values' , [] , ...
                        'rule' , [] , ...
                    'ref_stim' , [] , ...
                     'ref_par' , [] , ...
                      'ref_pi' , [] ) ;
    vpar4{i} = vpar4{i}( [] ) ;
    stim_var{i} = { vpar1{i} , vpar2{i} , vpar3{i} , vpar4{i} } ;
  end
  
  stim_schedule = cell( NB , 1 ) ;
  for i = 1 : NB
    stim_schedule{ i } = struct( 'rep' , rep( i ) , ...
      'attempts' , attempts , 'sind' , sind{ i } , 'pind' , pind{ i } , ...
      'params' , [] , 'deck' , deck{ i } ) ;
    stim_schedule{ i }.params = params{ i } ;
  end
  
  
  %-- Package block struct array --%
  
  block = struct( 'origins' , origins , 'stim_map' , stim_map , ...
    'task_d' , task_d , 'stim_d' , stim_d , 'stim_par' , stim_par , ...
    'stim_var' , stim_var , 'stim_schedule' , stim_schedule ) ;
  
  
end % blockdef
