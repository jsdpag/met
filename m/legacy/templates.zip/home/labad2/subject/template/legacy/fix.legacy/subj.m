
function  s = subj
% 
%  subj - returns struct - Describes essential information about the
%    subject, including fields
%   
%    .id - string - An anonymous subject identifier.
%    .dist_mm - numeric scalar - The distance of the subject's pupil from
%      the surface of the screen, in millimeters. [NOT USED]
%    .reward_s - numeric scalar - The duration of reward pump activation on
%      correct trials, in seconds.
% 
  
  s = struct( 'id' , 'M135' , 'dist_mm' , 200 , 'reward_s' , 0.24 ) ;
  
end % subj