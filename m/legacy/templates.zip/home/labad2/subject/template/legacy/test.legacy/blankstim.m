
function [ params , trialinit , draw , checksum , trialclose ] = blankstim
% 
% [ params , trialinit , draw , trialclose ] = blankstim
% 
% Defines a blank stimulus. Nothing is drawn. But the hitbox covers the
% whole screen. For detecting whether the mouse button is down or not.
% 
% 
% Output
% 
% params - one element struct - A default parameter set for the stimulus.
%   Each field names a different parameter, and points to the parameter's
%   value.
% 
% trialinit - function handle, trialinit( params , pardur , ptbwin )
%   Function is executed in preparation for each new trial. It returns a
%   stimulus trial descriptor that the drawing function will use. The
%   stimulus trial descriptor must have at least one field called .hitbox ;
%   this will be an 4 x M matrix of on-screen vertices (row order) for
%   each presented object (column order) describing the area that the
%   subject can hit.
%   
%   Three input arguments are required. params will be converted into the
%   stimulus trial descriptor, taking into account the screen parameters
%   provided by ptbwin.
%   
%   ptbwin.ptr - scalar number - PTB window pointer, as returned by
%     Screen( 'OpenWindow' )
%   ptbwin.origin - 2 element numerical vector - The origin in degrees from
%     the top left of the monitor. 
%   ptbwin.pixperdeg - numerical scalar - The number of pixels per degree
%     of visual angle. 
%   ptbwin.flipinterval - numerical scalar - The number of seconds between
%     successive screen refreshes, like the estimate provided by PTB-3
%     Screen( 'GetFlipInterval' , ... ).
%   ptbwin.background - 3 element vector, the RGB value of the window's
%     background.
%   
%   params must be a struct array of one or more elements. Multiple
%   parameter sets can be given to the same stimulus if the block
%   definition's task to concrete stimulus mapping says so. This allows the
%   same stimulus to respond to changes in task state. Consequently, it is
%   necessary to know the timeout associated with each parameter set. This
%   is given in pardur, an N by 2 matrix indexing columns by [ parameter
%   set index , state timeout ] and rows by each pairing. Thus,
%   pardur( i , 1 ) names the parameter set in params, and pardur( i , 2 )
%   says the associated state timeout.
%   
% 
% draw - function handle, draw( f , t , flip , stimtd, p ) - Drawing
%   function that is executed before each frame in which the stimulus is
%   presented. The function will return an updated stimulus trial
%   descriptor. Four input arguments are required. The frame number for
%   the next frame presentation. The duration from a time-zero flip and the
%   most recent frame, in seconds. The flip interval, in seconds. The
%   latest stimulus trial descriptor, initially returned by trialinit. The
%   parameter set index to use for drawing.
%   
%   NOTE: The taskcontroller must know the vbl for all frames generated.
%   flip is expected between each frame. The vbl of successive frames is f1
%   and f2. flip - ( f2 - f1 ) + ifi = 2 * ifi - f2 + f1 
% 
% checksum - function handle, checksum( stimtd ) - Adds together any
%   randomly generated components of stimtd into a checksum. This should be
%   done before and after the trial. If the pseudo-random number sequence
%   is successfully replicated, then the checksums will also be.
% 
% trialclose - function handle, trialclose( stimtd ) - Frees any resources
%   that were requested by trialinit. For example, textures are freed using
%   Screen( 'close' , textureIndeces ).
% 
% 
% Stimulus parameters - The parameters represented in params.
% 
%   offset - 2 element vector - offset( 1 ) x-axis i.e. horizontal and
%     offset( 2 ) y-axis i.e. azimuth offset from the origin, in degrees of
%     visual field. Using Screen coordinates convention, positive values
%     move right and down, negative values move left and up. Dot will be
%     bounded by the edge of the screen if offset sits beyond it.
%   
%   width - scalar - width of the dot in degrees of visual field
%   
%   colour - scalar or 3 element vector - Value between 0 and 1. If scalar,
%     then describes greyscale value. If vector then describes colour.
%   
%   alpha - scalar - Indicates level of transparency, value between 0 and 1
%     for invisible to opaque.
%   
% 
% Written by Jackson Smith - Nov 2015 - DPAG, University of Oxford
% 
  
  
  %%% No valid parameters %%%
  
  params = struct ;
  
  
  %%% Trial initialisation function %%%
  
  trialinit = @ftrialinit ;
  
  
  %%% Drawing function %%%
  
  draw = @fdraw ;
  
  
  %%% Checksum function %%%
  checksum = @fchecksum ;
  
  
  %%% Trial close function %%%
  
  trialclose = @ftrialclose ;
  
  
end % blankstim


function  stimtd = ftrialinit ( ~ , ~ , ptbwin )
  
  
  %%% Hit box covers whole screen %%%
  
  stimtd.hitbox = [ 0 , 0 , ptbwin.size_px( 1 ) , ptbwin.size_px( 2 ) ]' ;
  
  
end % ftrialinit


function  stimtd = fdraw ( ~ , ~ , ~ , stimtd , ~ )
  
  % Nothing to draw, but make sure that hitbox survives and returns
  
end % fdraw


function s = fchecksum( ~ )
  
  % Unlike random dots, there is no random component to this stimulus.
  % Return zero.
  s = 0 ;
  
end % fchecksum


function ftrialclose( ~ , ~ )
  
  % Nothing to free or reset
  
end % ftrialclose

