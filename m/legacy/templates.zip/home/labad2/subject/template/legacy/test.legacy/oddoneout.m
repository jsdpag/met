
function  task_d = oddoneout
%
% task_d = oddoneout
% 
% Defines an odd-one-out task. Returns a task descriptor containing all the
% information that is required by taskcontroller.m to run a task in which
% one target and several distractors are presented. The object of the task
% is to identify the one stimulus that is different from all others.
% 
% Task stimuli
% 
%   1 - 'Fixation' target, must be selected to start the task
%   2 - The target(s) that must be selected.
%   3 - The distractor(s) that must be avoided.
%   4 - Blank. No stimulus. But a hitbox will cover the entire screen. For
%     extending the pause state while the button is pressed.
% 
% Output
% 
% task_d - 1 element struct - Provides task parameters and a state set.
% 
%   .name - string - A human readable name that uniquely identifies this
%     task.
%   
%   .ntaskstim - scalar integer - The number of abstracted task stimuli
%     that this task supports. At least this numer of concrete stimulus
%     definitions must be mapped to the task stimuli. This may not
%     necessarily correspond to the number of objects on screen, as a
%     concrete stimulus may present any number of objects. Alternatively,
%     the same task stimulus may map to many different concrete stimulus
%     definitions.
%   
%   .taskstim - string - A handy-dandy description of what each task
%     stimulus is for. To the benefit of worried humans.
%   
%   .states - N element struct array - A set of state descriptors that
%     together define the task's behaviour and outcomes. There is scope for
%     logical branching and looping ; with our gobs of free time, we could
%     even design a high-level language on top of Matlab to quickly and
%     easily define a whole task, and 'compile' it into a task descriptor
%     function like this one.
% 
%   .states(i) - struct - The ith state descriptor.
%     
%     .name - string - Short but unique human readable state name.
%     .isend - scalar logical - Indicates whether this is (1) or is not (0)
%       an end state. End states, once reached, lead to termination of the
%       current trial. In addition, the .fnext function returns an ascii
%       character code instead of a states index.
%     .timeout - scalar positive integer - The number of seconds before the
%       state times out. This must be 0 for end states, and greater than 0
%       otherwise.
%     .fendcon - function handle, fendcon( targ ) - Function returns value
%       > 0 if the state's end condition has been met. Requires one input
%       parameter ; targ is a positive integer describing the index of the
%       task-stimulus that is currently being fixated by the subject (0
%       means no target is fixated). For end states, fendcon must always
%       return true. Note that a value of -1 for targ indicates null
%       target. That is, there was no new input from the subject.
%     .fnext - function handle, fnext( timeout , targ ) - Function
%       returns a positive integer. If .isend is 0 (state is not end state)
%       then fnext's output is the index of .states to switch to next. If
%       .isend is true (state is an end state) then fnext's output is an
%       ASCII character code that describes the outcome of the trial. Two
%       input parameters are required. 'timeout' is a scalar logical that
%       is true if the task has been in state states(i) for
%       states(i).timeout seconds or longer. 'targ' is the same as in
%       .fend.
%     .stim - N element integer vector - Lists integers between 1 and
%       .ntaskstim, to indicate which task stimuli are to be drawn in each
%       frame. 0 if there are no stimuli to draw. Must be 0 for end states.
%  
%  ntaskstim - The number of stimuli that the task can support.
% 
% 
% Version 5 - Waits for button release after start button hit. Hold too
% long and the trial breaks.
% 
% Written by Jackson Smith - Oct 2015 - DPAG, University of Oxford
%
  
  
  %%% Define task descriptor %%%
  
  task_d = struct( 'name' , [] , 'ntaskstim' , [] , 'states' , [] ) ;
  
  % Task name.
  task_d.name = 'odd-one-out v5' ;
  
  % Number of task stimuli. Convention: Stimulus 1 is the 'fixation'
  % target, Stimulus 2 is the odd one out target(s), Stimulus 3 is the
  % distractor(s), Stimulus 4 is the blank hitbox covering the whole
  % screen.
  task_d.ntaskstim = 4 ;
  
  % Task stimuli verbal description
  task_d.taskstim = ...
    [      '1) ''fixation'' target, selected to initiate trial.' , ...
      10 , '2) Target stimulus, selected on correct trials.' , ...
      10 , '3) Distractor stimulus, selected on failed trials.' , ...
      10 , '4) Blank stimulus, hitbox covers screen.' , 10 ] ;
  
  
  %%% State set definition %%%
  
  % Names
  name = { 'start' ;      % 1
           'pause' ;      % 2
           'stim_onset' ; % 3
           'correct' ;    % 4
           'failed' ;     % 5
           'ignored' ;    % 6
           'broken' } ;   % 7
  
  % Is end state
  isend = { false ;  % start
            false ;  % pause
            false ;  % stim_onset
            true ;   % correct
            true ;   % failed
            true ;   % ignored
            true } ; % broken
  
  % Timeout durations in seconds
  timeout = { 10.0  ;   % start
               5.0 ;   % pause
               5.0  ;   % stim_onset
               0.0  ;   % correct
               0.0  ;   % failed
               0.0  ;   % ignored
               0.0  } ; % broken
  
  % End condition assessor function
  fendcon = { @fendcon_start ;      % start
              @fendcon_pause ;      % pause
              @fendcon_stim_onset ; % stim_onset
              @fendcon_endstate ;   % correct
              @fendcon_endstate ;   % failed
              @fendcon_endstate ;   % ignored
              @fendcon_endstate } ; % broken
  
  % Next state / outcome function
  fnext = { @fnext_start ;      % start
            @fnext_pause ;      % pause
            @fnext_stim_onset ; % stim_onset
            @fnext_correct ;    % correct
            @fnext_failed ;     % failed
            @fnext_ignored ;    % ignored
            @fnext_broken } ;   % broken
	
	% Task stimuli to present
  stim = { 1 ;         % start
           4 ;         % pause
   [ 2 , 3 ] ;         % stim_onset
           0 ;         % correct
           0 ;         % failed
           0 ;         % ignored
           0 } ;       % broken
  
	
  % Build state descriptors
  task_d.states = ...
    struct( 'name' , name , ...
           'isend' , isend , ...
         'timeout' , timeout , ...
         'fendcon' , fendcon , ...
           'fnext' , fnext , ...
            'stim' , stim ) ;
  
  
end % oddoneout


%%% End condition functions %%%

function x = fendcon_start( targ )
  
  % Must hit stimulus 1 to proceed
  x =  targ == 1  ;
  
end % fendcon_start


function x = fendcon_pause( targ )
  
  % Wait for time out, and button release
  x = targ ~= 4 ;
  
end % fendcon_pause


function x = fendcon_stim_onset( targ )
  
  % Must be either target 2 or 3
  x =  any( targ == [ 2 , 3 ] )  ;
  
end % fendcon_stim_onset


function x = fendcon_endstate( ~ )
  
  % End state always ends
  x = 1 ;
  
end % fendcon_endstate


%%% Outcome functions %%%

function x = fnext_start( timeout , ~ )
  
  % Timed out, the trial was ignored
  if timeout
    
    x = 6 ;
    
  % the target was hit, move to pause
  else
    
    x = 2 ;
  
  end
  
end % fnext_start


function x = fnext_pause( timeout , targ )
  
  % Broken trial. Timeout or background was touched
  if timeout || targ == 0
    
    x = 7 ;
    
  % Stimulus onset is next
  else
    
    x = 3 ;
  
  end
  
end % fnext_pause


function x = fnext_stim_onset( timeout , targ )
  
  % Broken trial, or touch but not on target
  if timeout || targ == 0
    
    x = 7 ;
  
  else
    
    % The end states' states indeces are 4 - correct and 5 - failed.
    % targ 2 indicates that the odd one out was selected, 2 + 2 = 4
    % targ 3 indicates that a distractor was selected, 2 + 3 = 5
    x = targ + 2 ;
  
  end
  
end % fnext_stim_onset


function x = fnext_correct( ~ , ~ )
  x = double( 'c' ) ;
end


function x = fnext_failed( ~ , ~ )
  x = double( 'f' ) ;
end


function x = fnext_ignored( ~ , ~ )
  x = double( 'i' ) ;
end


function x = fnext_broken( ~ , ~ )
  x = double( 'b' ) ;
end

