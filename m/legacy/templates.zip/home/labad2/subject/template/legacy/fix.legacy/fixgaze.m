
function  task_d = fixgaze
%
% task_d = fixgaze
% 
% Defines a gaze-fixation task. Returns a task descriptor containing all
% the information that is required by taskcontroller.m to run a task in
% which one is presented that the subject must select and hold for a set
% amount of time.
% 
% Task stimuli
% 
%   0 - No target , implicitly passed by taskcontroller.m when the subject
%     selects a point outside of any hit box from a visible stimulus.
%     ntaskstim must not count this.
%   1 - 'Fixation' target, when subject is looking elsewhere
%   2 - 'Fixation' target, when subject is holding its gaze on the target
% 
% Output
% 
% task_d - 1 element struct - Provides task parameters and a state set.
% 
%   .name - string - A human readable name that uniquely identifies this
%     task.
%   
%   .ntaskstim - scalar integer - The number of abstracted task stimuli
%     that this task supports. At least this numer of concrete stimulus
%     definitions must be mapped to the task stimuli. This may not
%     necessarily correspond to the number of objects on screen, as a
%     concrete stimulus may present any number of objects. Alternatively,
%     the same task stimulus may map to many different concrete stimulus
%     definitions.
%   
%   .taskstim - string - A handy-dandy description of what each task
%     stimulus is for. To the benefit of worried humans.
%   
%   .states - N element struct array - A set of state descriptors that
%     together define the task's behaviour and outcomes. There is scope for
%     logical branching and looping ; with our gobs of free time, we could
%     even design a high-level language on top of Matlab to quickly and
%     easily define a whole task, and 'compile' it into a task descriptor
%     function like this one.
% 
%   .states(i) - struct - The ith state descriptor.
%     
%     .name - string - Short but unique human readable state name.
%     .isend - scalar logical - Indicates whether this is (1) or is not (0)
%       an end state. End states, once reached, lead to termination of the
%       current trial. In addition, the .fnext function returns an ascii
%       character code instead of a states index.
%     .timeout - scalar positive integer - The number of seconds before the
%       state times out. This must be 0 for end states, and greater than 0
%       otherwise.
%     .fendcon - function handle, fendcon( targ ) - Function returns value
%       > 0 if the state's end condition has been met. Requires one input
%       parameter ; targ is a positive integer describing the index of the
%       task-stimulus that is currently being fixated by the subject (0
%       means no target is fixated). For end states, fendcon must always
%       return true.
%     .fnext - function handle, fnext( timeout , targ ) - Function
%       returns a positive integer. If .isend is 0 (state is not end state)
%       then fnext's output is the index of .states to switch to next. If
%       .isend is true (state is an end state) then fnext's output is an
%       ASCII character code that describes the outcome of the trial. Two
%       input parameters are required. 'timeout' is a scalar logical that
%       is true if the task has been in state states(i) for
%       states(i).timeout seconds or longer. 'targ' is the same as in
%       .fendcon.
%     .stim - N element integer vector - Lists integers between 1 and
%       .ntaskstim, to indicate which task stimuli are to be drawn in each
%       frame. 0 if there are no stimuli to draw. Must be 0 for end states.
%  
%  ntaskstim - The number of stimuli that the task can support.
% 
% 
% Version 1 - Made for retrofitted legacy software that runs with MET.
% 
% Written by Jackson Smith - Dec 2016 - DPAG, University of Oxford
%
  
  
  %%% Define task descriptor %%%
  
  task_d = struct( 'name' , [] , 'ntaskstim' , [] , 'states' , [] ) ;
  
  % Task name.
  task_d.name = 'Gaze Fixation v1' ;
  
  % Number of task stimuli. Convention: Stimulus 1 is the 'fixation' target
  % that is not looked at, Stimulus 2 is the 'fixation' target that is
  % looked at.
  task_d.ntaskstim = 2 ;
  
  % Task stimuli verbal description
  task_d.taskstim = ...
    [      '1) ''fixation'' target, gaze elsewhere.' , ...
      10 , '2) ''fixation'' target, gaze on target.' , 10 ] ;
  
  
  %%% State set definition %%%
  
  % Names
  name = { 'start'    ;  % 1
           'no_fix'   ;  % 2
           'fixation' ;  % 3
           'correct'  ;  % 4
           'ignored'  ;  % 5
           'broken' } ;  % 6
  
  % Is end state
  isend = { false ;  % start
            false ;  % no_fix
            false ;  % fixation
            true ;   % correct
            true ;   % ignored
            true } ; % broken
  
  % Timeout durations in seconds
  timeout = { 10.0  ;   % start
               5.0  ;   % no_fix
               1.0  ;   % fixation
               0.0  ;   % correct
               0.0  ;   % ignored
               0.0  } ; % broken
  
  % End condition assessor function
  fendcon = { @fendcon_nofix ;      % start
              @fendcon_nofix ;      % no_fix
              @fendcon_fixation ;   % fixation
              @fendcon_endstate ;   % correct
              @fendcon_endstate ;   % ignored
              @fendcon_endstate } ; % broken
  
  % Next state / outcome function
  fnext = { @fnext_start    ;  % start
            @fnext_nofix    ;  % no_fix
            @fnext_fixation ;  % fixation
            @fnext_correct  ;  % correct
            @fnext_ignored  ;  % ignored
            @fnext_broken } ;  % broken
	
	% Task stimuli to present
  stim = { 1 ;         % start
           1 ;         % no_fix
           2 ;         % fixation
           0 ;         % correct
           0 ;         % ignored
           0 } ;       % broken
  
	
  % Build state descriptors
  task_d.states = ...
    struct( 'name' , name , ...
           'isend' , isend , ...
         'timeout' , timeout , ...
         'fendcon' , fendcon , ...
           'fnext' , fnext , ...
            'stim' , stim ) ;
  
  
end % fixgaze


%%% End condition functions %%%

function x = fendcon_nofix( targ )
  
  % Must hit stimulus 1 to proceed
  x =  targ == 1  ;
  
end % fendcon_start


function x = fendcon_fixation( targ )
  
  % Ends when nothing is selected
  x =  ~ targ  ;
  
end % fendcon_stim_onset


function x = fendcon_endstate( ~ )
  
  % End state always ends
  x = 1 ;
  
end % fendcon_endstate


%%% Outcome functions %%%

function x = fnext_start( timeout , targ )
  
  % Timed out, the trial was ignored
  if  timeout
    
    % Ignored
    x = 5 ;
    
  % the target was hit
  elseif  targ == 1
    
    % fixation
    x = 3 ;
  
  end
  
end % fnext_start


function x = fnext_nofix( timeout , targ )
  
  % Timed out without gazing at fixation point
  if  timeout
    
    % Broken
    x = 6 ;
    
  % Target was hit
  elseif  targ == 1
    
    % fixation
    x = 3 ;
  
  end
  
end % fnext_pause


function x = fnext_fixation( timeout , targ )
  
  % Timed out
  if  timeout
    
    % Correct
    x = 4 ;
  
  % Target dropped
  elseif  ~ targ
    
    % no_fix
    x = 2 ;
  
  end
  
end % fnext_stim_onset


function x = fnext_correct( ~ , ~ )
  x = double( 'c' ) ;
end


function x = fnext_ignored( ~ , ~ )
  x = double( 'i' ) ;
end


function x = fnext_broken( ~ , ~ )
  x = double( 'b' ) ;
end

