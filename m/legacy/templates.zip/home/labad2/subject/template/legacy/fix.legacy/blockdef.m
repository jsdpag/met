
function  block = blockdef
% 
% block = blockdef
% 
% Defines a fixation task with a single block.
% 
% Output
% 
% block - struct array - Defines the trial block structure, including which
%   stimuli are used and what their parameters are.
% 
% block(i) - the ith block of trials
%   
%   .origins - numerical, 4 element vector or N x 2 matrix - Used to
%     define the stimulus-drawing point of origin within the screen. A
%     different origin will be sampled, for variation in the absolute
%     position of stimuli. If a 4 element vector is given, then it will
%     have the format [ left edge , top edge , right edge , bottom edge ]
%     defining a box in degrees relative to the centre of the screen. Any
%     origin may be sampled from within its bounds. The matrix format
%     provides a list of N points that are randomly sampled, with the
%     column order being [ x position , y position ] in degrees from the
%     centre of the screen.
%     
%     See [ RectLeft , RectTop , RectRight , RectBottom ]
%   
%   .stim_map - struct array, row vector 1 x N - Describes the mapping
%     between each task stimulus and concrete stimulus descriptors. It is
%     required that all index vectors contained therein are sorted
%     ascending.
%   
%     stim_map(j) - Map for the ith task stimulus
%       .con - integer vector - indeces of concrete stimuli that map to the
%         jth abstract task stimulus. Each index may only appear once.
%       .par - The corresponding index for the stimulus's parameter struct
%         array.  Thus stimulus .con(k) uses its .par(k)'th parameter set.
%
%   .task_d - function handle - Returns a task descriptor struct with
%     information about the task and its behaviour.
% 
%   .stim_d - cell array of M elements - Contains stimulus descriptor
%     functions. One per concrete stimulus.
%   .stim_d{j} - function handle - Stimulus descriptor function. Returns
%     default parameters and trial initialiser, drawing, checksum, and
%     closing functions.
%   
%   .stim_par - cell array - contains parameter struct arrays for each
%     stimulus listed in .stim_d.
%   .stim_par{j} - struct array - The parameters for stimulus j, to be used
%     in this block of trials.
%   
%   .stim_var - cell array - one element per concrete stimulus - Describes
%     how to sample variable stimulus parameters from trial to trial.
%   .stim_var{j} - N x 1 struct array - Sampling schedule for jth concrete
%     stimulus. Make this an empty struct of the right kind if there are no
%     variable parameters for a given stimulus.
%   .stim_var{j}(k) - The kth variable parameter of the jth concrete
%     stimulus. Describes if it is sampled independently, or dependently on
%     a reference parameter.
%     
%     .param - string - Names the variable parameter. Must be in the set of
%       parameters from the stimulus descriptor function.
%     .pari - scalar integer - index of stimulus's parameter set.
%     .values - numeric vector - The set of values to sample from.
%     .rule - scalar integer - The sampling rule. 0 sample independently. 1
%       use the same value as the reference. -1 use any value other than
%       what the reference is using. If 0 then the .ref_* fields aren't
%       used and can have any place-holder value.
%     .ref_stim - scalar integer - Index of .stim_par, identifying the
%       reference stimulus containing the reference parameter.
%     .ref_par - string - Names the reference parameter.
%     .ref_pi - scalar integer - index of ref stim's parameter set.
%
%   .stim_schedule - one element struct - Describes hard-wired schedule of
%     parameter values per trial. These are presented in a randomised
%     order. If a trial is ignored, broken, or aborted then the parameters
%     are randomly reshuffled into the deck.
%     
%     .rep - scalar integer - Repetitions of the given schedule deck to
%       present in each block. 
%     .attempts - scalar integer - The number of times a single set of
%       parameters will be reshuffled into the deck following broken
%       trials. Doesn't count for ignored or aborted.
%     .sind - integer vector - N elements, one for each parameter in the
%       schedule. .sind(i) is the ith index that references corresponding
%       elements in .stim_d and .stim_par.
%     .pind - integer vector - N elements, one for each parameter in the
%       schedule. .pind(i) is the ith index that references which stimulus
%       parameters in .stim_par{ .sind(i) } to set. If 0, then the
%       scheduled value is applied to all .stim_par{ .sind(i) }( : ) sets.
%     .params - cell array vector of strings - N elements, names which
%       parameters to set. .params{i} refers to the same stimulus as
%       .sind(i) and .pind(i).
%     .deck - M x N double matrix - The set of scheduled parameter values.
%       Each record (row) describes the parameter values on a single trial.
%       Each field (column) corresponds to an element of .sind, .pind, and
%       .params. For example, .deck( m , n ) describes the value of
%       parameter .params{ n } in parameter set .pind( n ) for concrete
%       stimulus .sind( n ) ; while .deck( m , n + 1 ) describes the value
%       of the next parameter on the same trial.
% 
% 
% Function dependencies: tdotf.m , fixgaze.m
% 
% 
% Written by Jackson Smith - Dec 2016 - DPAG, University of Oxford
%
  
  % Origin box
  block.origins = [ -15 , -15 , 15 , 15 ] ;
  
  % Task stimulus to concrete stimulus map
  block.stim_map = struct ( 'con' , { 1 , 2 } , 'par' , { 1 , 1 } ) ;
  
  % The task
  block.task_d = @fixgaze ;
  
  % Concrete stimulus descriptor functions
  block.stim_d = { @tdotf , @tdotf } ;
  
  % Parameters for each concrete stimulus
  block.stim_par = { tdotf , tdotf } ;
  
    % By definition in fixgaze, the second task stimulus, which maps to the
    % second concrete stimulus, is the target when fixation is on. So, turn
    % off flashing.
    block.stim_par{ 2 }.flashrate = 0 ;
  
  % Variable stimulus parameters , varying from trial to trial. There is no
  % parameter that needs to vary , so return an empty struct with the
  % correct field names.
  block.stim_var = { [] , [] } ;
  block.stim_var{ 1 } = struct( 'param' , {} , ...
                                 'pari' , {} , ...
                               'values' , {} , ...
                                 'rule' , {} , ...
                             'ref_stim' , {} , ...
                              'ref_par' , {} , ...
                               'ref_pi' , {} ) ;
	block.stim_var{ 2 } = block.stim_var{ 1 } ;
  
	% The schedule , this is more of a placeholder as there is nothing to
	% vary between trials, at this point. The only variable is the position,
	% which changes as the origin is sampled by taskcontroller.m
  block.stim_schedule.rep = 100 ;
  block.stim_schedule.attempts = 3 ;
  block.stim_schedule.sind =   1 : 2 ;
  block.stim_schedule.pind = [ 1 , 1 ] ;
  block.stim_schedule.params = { 'width' , 'width' } ;
  block.stim_schedule.deck = ...
    ( 0.4 : 0.2 : 1 )' * [ 1 , 1 ] ;
  
end  % blockdef

