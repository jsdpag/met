
function [ params , trialinit , draw , checksum , trialclose ] = tdotf
% 
% [ params , trialinit , draw , trialclose ] = tdotf
% 
% Defines a single dot stimulus, providing all of the information that is
% required by taskcontroller.m. This kind of dot can flash at a fixed rate.
% 
% 
% Output
% 
% params - one element struct - A default parameter set for the stimulus.
%   Each field names a different parameter, and points to the parameter's
%   value.
% 
% trialinit - function handle, trialinit( params , pardur , ptbwin )
%   Function is executed in preparation for each new trial. It returns a
%   stimulus trial descriptor that the drawing function will use. The
%   stimulus trial descriptor must have at least one field called .hitbox ;
%   this will be an 4 x M matrix of on-screen vertices (row order) for
%   each presented object (column order) describing the area that the
%   subject can hit.
%   
%   Three input arguments are required. params will be converted into the
%   stimulus trial descriptor, taking into account the screen parameters
%   provided by ptbwin.
%   
%   ptbwin.ptr - scalar number - PTB window pointer, as returned by
%     Screen( 'OpenWindow' )
%   ptbwin.origin - 2 element numerical vector - The origin in pixels from
%     the top left of the monitor. 
%   ptbwin.pixperdeg - numerical scalar - The number of pixels per degree
%     of visual angle. 
%   ptbwin.flipinterval - numerical scalar - The number of seconds between
%     successive screen refreshes, like the estimate provided by PTB-3
%     Screen( 'GetFlipInterval' , ... ).
%   ptbwin.background - 3 element vector, the RGB value of the window's
%     background.
%   
%   params must be a struct array of one or more elements. Multiple
%   parameter sets can be given to the same stimulus if the block
%   definition's task to concrete stimulus mapping says so. This allows the
%   same stimulus to respond to changes in task state. Consequently, it is
%   necessary to know the timeout associated with each parameter set. This
%   is given in pardur, an N by 2 matrix indexing columns by [ parameter
%   set index , state timeout ] and rows by each pairing. Thus,
%   pardur( i , 1 ) names the parameter set in params, and pardur( i , 2 )
%   says the associated state timeout.
%   
% 
% draw - function handle, draw( f , t , flip , stimtd, p ) - Drawing
%   function that is executed before each frame in which the stimulus is
%   presented. The function will return an updated stimulus trial
%   descriptor. Four input arguments are required. The frame number for
%   the next frame presentation. The duration from a time-zero flip and the
%   most recent frame, in seconds. The flip interval, in seconds. The
%   latest stimulus trial descriptor, initially returned by trialinit. The
%   parameter set index to use for drawing.
%   
%   NOTE: The taskcontroller must know the vbl for all frames generated.
%   flip is expected between each frame. The vbl of successive frames is f1
%   and f2. flip - ( f2 - f1 ) + ifi = 2 * ifi - f2 + f1 
% 
% checksum - function handle, checksum( stimtd ) - Adds together any
%   randomly generated components of stimtd into a checksum. This should be
%   done before and after the trial. If the pseudo-random number sequence
%   is successfully replicated, then the checksums will also be.
% 
% trialclose - function handle, trialclose( stimtd ) - Frees any resources
%   that were requested by trialinit. For example, textures are freed using
%   Screen( 'close' , textureIndeces ).
% 
% 
% Stimulus parameters - The parameters represented in params.
% 
%   offset - 2 element vector - offset( 1 ) x-axis i.e. horizontal and
%     offset( 2 ) y-axis i.e. azimuth offset from the origin, in degrees of
%     visual field. Using Screen coordinates convention, positive values
%     move right and down, negative values move left and up. Dot will be
%     bounded by the edge of the screen if offset sits beyond it.
%   
%   width - scalar - width of the dot in degrees of visual field
%   
%   hbwid - scalar - Hit box width, box is centred on dot
%   
%   colour - scalar - Value between 0 and 1. A greyscale value for the dot
%     when it is not flashing.
%   
%   flashrate - scalar - The number of greyscale cycles per second. One
%     whole cycle varies the dot's greyscale sinusoidally through one whole
%     period. If zero then dot does not flash and colour is used.
%   
%   alpha - scalar - Indicates level of transparency, value between 0 and 1
%     for invisible to opaque.
%   
% 
% Written by Jackson Smith - Dec 2016 - DPAG, University of Oxford
% 
  
  
  %%% Default parameters %%%
  
  params = { 'offset' , [ 0 , 0 ] ;
              'width' , 1 ;
              'hbwid' , 1.25 ;
             'colour' , 0.8 ;
          'flashrate' , 5 ;
              'alpha' , 1 }' ;
  
  % Repackage parameters into a struct.
  params = struct( params{ : } ) ;
  
  
   %%% Trial initialisation function %%%
  
  trialinit = @ftrialinit ;
  
  
  %%% Drawing function %%%
  
  draw = @fdraw ;
  
  
  %%% Checksum function %%%
  checksum = @fchecksum ;
  
  
  %%% Trial close function %%%
  
  trialclose = @ftrialclose ;
  
  
end % tdot


function  stimtd = ftrialinit ( params , ~ , ptbwin )
  
  
  %%% Convert parameters to usable form, in pixel-based units %%%
  
  % Shorten the name params to p, for ease.
  p = params(1) ;
  
  % Convert degrees to pixels.
  for F = { 'offset' , 'width' , 'hbwid' } , f = F{1} ;
    p.(f) = p.(f) * ptbwin.pixperdeg ;
  end
  
  
  %%% Choose a rectangle size and position %%%
  
  % base rectangle in upper left corner, for easy correct width
  r = zeros ( 1 , 4 ) ;
  r( [ RectRight , RectBottom ] ) = p.width ;
  
  % center of dot
  dc = num2cell( ptbwin.origin + p.offset ) ;
  
  % center rectangle on offset
  r = CenterRectOnPoint( r , dc{ : } ) ;
  
  % Look for screen over-run and adjust
  % Horizontal adjustment
  if r( RectLeft ) < 0  &&  r( RectRight ) <= ptbwin.size_px( 1 )
    dx = -r( RectLeft ) ;
    
  elseif 0 <= r( RectLeft )  &&  ptbwin.size_px( 1 ) < r( RectRight )
    dx = ptbwin.size_px( 1 ) - r( RectRight ) ;
    
  else
    dx = 0 ;
  end
  
  % Vertical adjustment
  if r( RectTop ) < 0  &&  r( RectBottom ) <= ptbwin.size_px( 2 )
    dy = -r( RectTop ) ;
    
  elseif 0 <= r( RectTop )  &&  ptbwin.size_px( 2 ) < r( RectBottom )
    dy = ptbwin.size_px( 2 ) - r( RectBottom ) ;
    
  else
    dy = 0 ;
  end
  
  r( [ RectLeft , RectRight ] ) = r( [ RectLeft , RectRight ] ) + dx ;
  r( [ RectTop , RectBottom ] ) = r( [ RectTop , RectBottom ] ) + dy ;
  
  
  %%% Hit box %%%
  
  % base rectangle in upper left corner, for easy correct width
  hb = zeros ( 1 , 4 ) ;
  hb( [ RectRight , RectBottom ] ) = p.hbwid ;
  
  % Centre of dot
  [ dc{ : } ] = RectCenter ( r ) ;
  
  % Centre hit box on dot
  hb = CenterRectOnPoint( hb , dc{ : } ) ;
  
  
  %%% Set colour and alpha level %%%
  
  c = [ ones( 1 , 3 ) * p.colour , p.alpha ] ;
  
  
  %%% Done, return stimulus trial state descriptor %%%
  
  stimtd.d = { 'FillOval' , ptbwin.ptr , c , r , p.width + 1 } ;
  stimtd.fr = 2 * pi * p.flashrate ;
  stimtd.hitbox = hb( : ) ;
  
  
end % ftrialinit


function  stimtd = fdraw ( ~ , t , ~ , stimtd , ~ )
  
  % Attempt to set alpha blending for anti-aliased edges
  Screen( 'BlendFunction' , stimtd.d{ 2 } , ...
    GL_SRC_ALPHA , GL_ONE_MINUS_SRC_ALPHA ) ;
  
  % Dot is flashing so calculate the greyscale value
  if  stimtd.fr
    c = sin ( stimtd.fr  *  t ) / 2  +  0.5 ;
    stimtd.d{ 3 }( 1 : 3 ) = c ;
  end
  
  % Draw the oval
  Screen ( stimtd.d{ : } ) ;
  
end % fdraw


function s = fchecksum( ~ )
  
  % Unlike random dots, there is no random component to this stimulus.
  % Return zero.
  s = 0 ;
  
end % fchecksum


function ftrialclose( ~ , ~ )
  
  % Nothing to free or reset
  
end % ftrialclose

