
function [ params , trialinit , draw , checksum , trialclose ] = rdk
% 
% [ params , trialinit , draw , trialclose ] = rdk
% 
% Defines a random-dot kinetogram stimulus that provides all of the
% information that is required by taskcontroller.m to draw one or more rdk
% stimuli with identical parameters on screen.
% 
% RDK's will have circular apertures, while dot dynamics will be made to
% resemble that of:
% 
%   Britten KH, Shadlen MN, Newsome WT, Movshon JA. 1992. The analysis of
%     visual motion: a comparison of neuronal and psychophysical
%     performance. J Neurosci. 12(12):4745-65.
% 
% Output
% 
% params - one element struct - A default parameter set for the stimulus.
%   Each field names a different parameter, and points to the parameter's
%   value.
% 
% trialinit - function handle, trialinit( params , pardur , ptbwin )
%   Function is executed in preparation for each new trial. It returns a
%   stimulus trial descriptor that the drawing function will use. The
%   stimulus trial descriptor must have at least one field called .hitbox ;
%   this will be an 4 x M matrix of on-screen vertices (row order) for
%   each presented object (column order) describing the area that the
%   subject can hit.
%   
%   Three input arguments are required. params will be converted into the
%   stimulus trial descriptor, taking into account the screen parameters
%   provided by ptbwin.
%   
%   ptbwin.ptr - scalar number - PTB window pointer, as returned by
%     Screen( 'OpenWindow' )
%   ptbwin.origin - 2 element numerical vector - The origin in pixels from
%     the top left of the monitor. 
%   ptbwin.pixperdeg - numerical scalar - The number of pixels per degree
%     of visual angle. 
%   ptbwin.flipinterval - numerical scalar - The number of seconds between
%     successive screen refreshes, like the estimate provided by PTB-3
%     Screen( 'GetFlipInterval' , ... ).
%   ptbwin.background - 3 element vector, the RGB value of the window's
%     background.
%   
%   params must be a struct array of one or more elements. Multiple
%   parameter sets can be given to the same stimulus if the block
%   definition's task to concrete stimulus mapping says so. This allows the
%   same stimulus to respond to changes in task state. Consequently, it is
%   necessary to know the timeout associated with each parameter set. This
%   is given in pardur, an N by 2 matrix indexing columns by [ parameter
%   set index , state timeout ] and rows by each pairing. Thus,
%   pardur( i , 1 ) names the parameter set in params, and pardur( i , 2 )
%   says the associated state timeout.
%   
% 
% draw - function handle, draw( f , t , flip , stimtd, p ) - Drawing
%   function that is executed before each frame in which the stimulus is
%   presented. The function will return an updated stimulus trial
%   descriptor. Four input arguments are required. The frame number for
%   the next frame presentation. The duration from a time-zero flip and the
%   most recent frame, in seconds. The flip interval, in seconds. The
%   latest stimulus trial descriptor, initially returned by trialinit. The
%   parameter set index to use for drawing.
%   
%   NOTE: The taskcontroller must know the vbl for all frames generated.
%   ifi is expected between each frame. The vbl of successive frames is f1
%   and f2. ifi - ( f2 - f1 ) + ifi = 2 * ifi - f2 + f1 
% 
% checksum - function handle, checksum( stimtd ) - Adds together any
%   randomly generated components of stimtd into a checksum. This should be
%   done before and after the trial. If the pseudo-random number sequence
%   is successfully replicated, then the checksums will also be.
% 
% trialclose - function handle, trialclose( stimtd ) - Frees any resources
%   that were requested by trialinit. For example, textures are freed using
%   Screen( 'close' , textureIndeces ).
% 
% 
% Stimulus parameters - The parameters represented in params.
% 
%   %-- formation circle --%
%   
%   N - scalar integer - The number of rdk patches to draw. Each patch is
%     drawn an equal distance from its two neighbours on the circumfrance
%     of an imaginary circle, called here the formation circle. Thus, N
%     patches will be placed on N points of the formation circle that
%     divide the circumfrance into N segments with the same length. In
%     other words, 360 / N degrees will separate every pair of neighbouring
%     points along the circumfrance of the formation circle. By default,
%     the first patch will be placed to the right of the circle's centre ;
%     that is, it's polar coordinate with respect to the centre will be one
%     circle's radius and an angle of zero.
%   
%   fcentre - 2 element double - Central point of the formation circle with
%     respect to the common point in ptbwin.origin, in degrees of visual
%     field. If set to [ dx , dy ] then the rdk formation circle centre
%     becomes ptbwin.origin + [ dx , dy ], a translation.
%   
%   fradius - scalar double - Radius of the formation circle, in degrees of
%     visual field.
%   
%   frotation - scalar double - Counter-clockwise rotation of the formation
%     circle, in degrees. That is, the rotation of rdk patch centres around
%     the centre of the formation circle.
%   
%   ffirst - scalar double - Index of the first drawn patch. This allows
%     fewer rdk patches to be drawn than indicated by N, while retaining
%     the same formation as with N patches. For instance, if N is 4 but
%     ffirst is 2 while frotation is 0, then 3 patches are drawn at angles
%     of pi/2, pi, and 3*pi/2.
%   
%   flast - scalar double - Index of the final drawn patch. Must be equal
%     to or greater than ffirst, and equal to or less than N.
%   
%   
%   %-- dot parameters --%
%   
%   radius - scalar double - Radius of each rdk circular aperture, in
%     degrees of visual field.
%   
%   coherence - scalar double , range [ 0 , 1 ] - Fraction of dots that
%     move with the same motion vector. In practice, this will always be
%     slightly less than stated, as some coherent dots are continually
%     being extinguished and replotted elsewhere.
%   
%   direction - scalar double - The angle, in degrees, of counter-clockwise
%     rotation about the centre of the rdk aperture of the coherent dot
%     motion vector.
%   
%   speed - scalar double - The speed of coherent dots in degrees of visual
%     field per second.
%   
%   density - scalar double - The density of dots, in dots per squared
%     degrees of visual field. This measure only counts the number of dot
%     centres per unit area of screen ; it does not account for overlapping
%     dots.
%   
%   width - scalar double - The width of each dot, in degrees of visual
%     field.
%   
%   avglife - scalar double - The average lifetime of a dot, in seconds.
%     Here lifetime is defined as the number of frames that a dot survives
%     for once it becomes coherent. All dots live at least one frame. 
%   
%   contrast - scalar double, range [ 0 , 1 ] or { -1 , -2 } - The dots are
%     evenly split into groups that are lighter or darker than the
%     background, if possible. If a value between 0 and 1 is given, then
%     this defines the Michelson contrast of the two shades that are used.
%     On the other hand, if one of two special flags are given ( -1 or -2 )
%     then all of the dots are made to be white (-1) or black (-2).
%   
% 
% Written by Jackson Smith - Jan 2016 - DPAG, University of Oxford
% 
  
  
  %%% Build parameters %%%

  % Parameter names and values, listed in a cell array for convenience.
  % Note the transposition, this is key for making the struct.
  params = {        'N' , 4 ;
              'fcentre' , [ 0 , 0 ] ;
              'fradius' , 6.5 ;
            'frotation' , 45 ;
               'ffirst' , 1 ;
                'flast' , 4 ;
               'radius' , 3 ;
            'coherence' , 0.5 ;
            'direction' , 0 ;
                'speed' , 3 ;
              'density' , 4 ;
                'width' , 0.2
              'avglife' , 45 / 1e3 ;
             'contrast' , 1 }' ;

  % Repackage parameters into a struct.
  params = struct( params{ : } ) ;
  
  
  %%% Trial initialisation function %%%
  
  trialinit = @ftrialinit ;
  
  
  %%% Drawing function %%%
  
  draw = @fdraw ;
  
  
  %%% Checksum function %%%
  checksum = @fchecksum ;
  
  
  %%% Trial close function %%%
  
  trialclose = @ftrialclose ;
  
  
end % rdk


%%% Output functions %%%

function stimtd = ftrialinit( params , ~ , ptbwin )
  
  
  %%% Check parameters %%%
  
  %-- Define checks for each parameter --%
  
  % C.parameter = [ number of elements , minimum value , integer ]
  C = { 'N' , [ 1 , 1 , 1 ] ;
  'fcentre' , [ 2 , -Inf , 0 ] ;
  'fradius' , [ 1 , 0 + eps( 0 ) , 0 ] ;
'frotation' , [ 1 , -Inf , 0 ] ;
   'ffirst' , [ 1 , 1 , 1 ] ;
    'flast' , [ 1 , 1 , 1 ] ;
   'radius' , [ 1 , 0 + eps( 0 ) , 0 ] ;
'coherence' , [ 1 , 0 , 0 ] ;
'direction' , [ 1 , -Inf , 0 ] ;
    'speed' , [ 1 , 0 , 0 ] ;
  'density' , [ 1 , 0 , 0 ] ;
    'width' , [ 1 , 0 + eps( 0 ) , 0 ] ;
  'avglife' , [ 1 , ptbwin.flipinterval , 0 ] ;
 'contrast' , [ 1 , -2 , 0 ] }' ;
  
  C = struct ( C{ : } ) ;
  
  
  %-- Checks each parameter --%
  
  % Parameter sets
  for i = 1 : numel( params )
      
    % All parameters - generic validity check
    for F = fieldnames( params )' , f = F{ 1 } ;
      
      % Get parameter value(s)
      p = params( i ).( f ) ;

      % validity check
      if  ~isnumeric ( p ) || any ( isnan ( p ) ) || ...
          numel ( p ) ~= C.( f )( 1 )  ||  any ( p < C.( f )( 2 ) ) || ...
          ( C.( f )( 3 )  &&  any( mod ( p , 1 ) ) )
        
        % Type of number
        if C.( f )( 3 )
          p = 'integer' ;
        else
          p = 'double' ;
        end
        
        error ( 'rdk:trialinit:%f needs %i element, min %f, is %s' , ...
          f , p )
        
      end % error detected

    end % parameters
    
    % Check uniformity in certain parameters across sets
    for F = { 'N' , 'ffirst' , 'flast' , 'density' , 'radius' } ;
      f = F{ 1 } ;
      
      % Check against reference value
      if params( 1 ).( f ) ~= params( i ).( f )
        
        error ( 'rdk:trialinit:%f not same in all par sets' , f )

      end % check
      
    end % uniform parameters
    
    % Special checks  
    if params( i ).N < params( i ).ffirst
      
      error ( 'rdk:trialinit:N < ffirst' )
      
    elseif params( i ).flast < params( i ).ffirst || ...
        params( i ).N < params( i ).flast
      
      error ( 'rdk:trialinit:flast < ffirst or N < flast' )
      
    elseif 1 < params( i ).coherence
      
      error ( 'rdk:trialinit:1 < coherence' )
      
    elseif ~( any ( params( i ).contrast == [ -1 , -2 ] ) || ...
        ( 0 <= params( i ).contrast && params( i ).contrast <= 1 ) )
      
      error ( 'rdk:trialinit:contrast not in set [0,1] or {-1,-2}' )
      
    end % special checks
    
  end % parameter sets
  
  
  %%% Unit conversions %%%
  
  %-- Degrees of visual field to pixels --%
  
  % Parameters given in degrees of visual field
  for F = { 'fcentre' , 'fradius' , 'radius' , 'speed' , 'width' } ;
    f = F{ 1 } ;
    
    % Parameter sets
    for i = 1 : numel( params )
      
      % Convert into pixels
      params( i ).( f ) = params( i ).( f ) * ptbwin.pixperdeg ;
      
    end % parameter sets
    
  end % converted parameters
  
  %-- Squared degrees of visual field to squared pixels --%
  
  % Parameter sets
  for i = 1 : numel( params )

    % Convert into pixels
    params( i ).density = params( i ).density / ptbwin.pixperdeg ^ 2 ;

  end % parameter sets
  
  %-- Degrees to radians --%
  
  % Parameters given in degrees
  for F = { 'frotation' , 'direction' } ; f = F{ 1 } ;
    
    % Parameter sets
    for i = 1 : numel( params )
      
      % Convert into radians
      params( i ).( f ) = params( i ).( f ) * pi / 180 ;
      
    end % parameter sets
    
  end % converted parameters
  
  %-- Flip sign of rotations --%
  
  % Because the screen coordinate system is mirrored across the x-axis,
  % with respect to a conventional Cartesian coordinate system, we must
  % change the +'ve or -'ve sign on the rotation values in order to achieve
  % the intended direction of rotation.
  
  % Parameters given in counter-clockwise rotation
  for F = { 'frotation' , 'direction' } ; f = F{ 1 } ;
    
    % Parameter sets
    for i = 1 : numel( params )
      
      % Convert into radians
      params( i ).( f ) = -params( i ).( f ) ;
      
    end % parameter sets
    
  end % converted parameters
  
  
  %%% Build stimulus trial descriptor %%%
  
  % We will assume that the task starts with parameter set 1.
  pdef = 1 ;
  
  % PTB window pointer
  stimtd.ptr = ptbwin.ptr ;
  
  % Stimulus origin in the PTB window, converted into pixels
  stimtd.origin = ptbwin.origin ;
  
  % Number of seconds per frame
  stimtd.flipinterval = ptbwin.flipinterval ;
  
  % PTB window background colour
  stimtd.background = ptbwin.background ;
  
  % PTB window black and white intensity values
  stimtd.black = BlackIndex ( ptbwin.ptr ) ;
  stimtd.white = WhiteIndex ( ptbwin.ptr ) ;
  
  % Flag signals that the first frame has not been drawn
  stimtd.frame1 = true ;
  
  % Total number of patch locations on the formation circle
  stimtd.N = params( pdef ).N ;
  
  % First patch on the circle to be drawn
  stimtd.fp = params( pdef ).ffirst ;
  
  % Last patch on the circle to be drawn
  stimtd.lp = params( pdef ).flast ;
  
  % The number of drawn dot patches
  stimtd.np = stimtd.lp - stimtd.fp + 1 ;
  
  % Radius of a dot patch
  stimtd.dprad = params( pdef ).radius ;
  
  % Area of a dot patch
  a = pi * params( pdef ).radius ^ 2 ;
  
  % The number of dots per patch
  stimtd.dpp = ceil (  a  *  params( pdef ).density  ) ;
  
  % Total number of dots
  stimtd.nd = stimtd.np * stimtd.dpp ;
  
  % Index of the parameter set used last draw. This is checked in the draw
  % function against the given index. Values are updated when a change is
  % detected.
  stimtd.p = pdef ;
  
  % Collect parameter sets
  stimtd.pset = params ;
  
  % Compute the probability of survival, the raw motion vector, the
  % rotation matrix, the translation matrix, and the colours, for all of
  % the dots.
  
  % Memory pre-allocation
  stimtd.sprob = 0 ;
  stimtd.motion = 0 ;
  stimtd.rotation = zeros ( 2 ) ;
  stimtd.translation = zeros ( 2 , stimtd.nd ) ;
  stimtd.colour = zeros ( 3 , stimtd.nd ) ;
  stimtd.hitbox = zeros ( 4 , stimtd.np ) ;
  
  % compute
  stimtd = updatepar ( stimtd ) ;
  
  % Memory pre-allocation for raw dot coordinates
  stimtd.rawxy = zeros ( 2 , stimtd.nd ) ;
  
  % Randomly generate raw starting positions
  [ stimtd.rawxy( 1 , : ) , ...
    stimtd.rawxy( 2 , : ) ] = rndxy ( params( pdef ).radius , stimtd.nd ) ;
  
  % Dot coherence state. True if dot is coherent
  stimtd.coh = false ( 1 , stimtd.nd ) ;
  
  % dot lifetime vector, in frames. Zero denotes a noise dot
  stimtd.lifetime = zeros ( 1 , stimtd.nd ) ;
  
  
end % ftrialinit


function stimtd = fdraw( ~ , ~ , ~ , stimtd , ~ )%p )
  
  
  %%% CONSTANTS %%%
  
  % stimtd.rawxy row indeces for x and y coordinates
  X = 1 ;
  Y = 2 ;
  
  
  %%% Check parameter set %%%
  
%   % Has the parameter set changed?
%   if  p  ~=  stimtd.p
%     
%     % Update the index ...
%     stimtd.p = p ;
%     
%     % ... and dependent dot parameters
%     stimtd = updatepar ( stimtd ) ;
%     
%   end % parameter set change
%   
%   % Current parameter set
%   par = stimtd.pset( p ) ;
  % Current parameter set
  par = stimtd.pset( stimtd.p ) ;
  
  
  %%% Prepare dots %%%
  
  % First, in case the coherence has changed, how many coherent dots do we
  % need per dot patch?
  ncoh = ceil ( stimtd.dpp * par.coherence ) ;
  
  % Special case, no coherent dots
  if ~ncoh
    
    % Set all to be noise dots
    stimtd.coh( : ) = false ;
    stimtd.lifetime( : ) = 0 ;
    
  % update coherent dots
  else
    
    % The motion-ward edge of the aperture at the y-axis coordinate of each
    % dot
    edge = sqrt ( par.radius ^ 2 - stimtd.rawxy( Y , : ) .^ 2 ) ;
    
    % Which dots are far enough from the aperture's edge to travel
    % for another frame?
    far =  stimtd.motion < edge - stimtd.rawxy( X , : ) ;
    
    % Noise dots
    noisy = ~stimtd.coh ;
    
    % Coherent dots that still have frames
    live = stimtd.coh  &  0 < stimtd.lifetime ;
    
    % Count how many living coherent dots there are in each patch
    nlive = sum ( reshape ( live , stimtd.dpp , stimtd.np ) ) ;
    
    % The difference in the number of coherent dots per patch, for the
    % upcoming frame
    ndiff = abs ( nlive - ncoh ) ;
    
    % Dot patch index vector. Just add this to the starting index of the
    % first dot in a given patch to access all of the patch's dots
    d = 0 : stimtd.dpp - 1 ;
    
    % Loop dot patches and adjust the number of coherent dots in each one
    for dp = 1 : stimtd.np
      
      % Index of the first dot in the patch
      d1 = ( dp - 1 ) * stimtd.dpp + 1 ;
      j = d1 + d ;
      
      % We need fewer coherent dots
      if ncoh < nlive( dp )

        % Find coherent dots to strip
        dsearch = live( j ) ;

        % Remove coherence flag
        cohswitch = false ;

        % Zero lifetimes
        newlife = zeros( 1 , ndiff( dp ) ) ;

      % We need more dots
      elseif nlive( dp ) < ncoh

        % Find noise dots to turn into coherent dots
        dsearch = noisy( j ) & far( j ) ;

        % Engage coherence flag
        cohswitch = true ;

        % Sample lifetimes. Guaranteed at least two frames. Don't add 1
        % because these random dots have been drawn for one frame already
        newlife = rndlifetime ( ndiff( dp ) , stimtd.sprob ) ;

      % We have all the coherent dots we need
      else
        
        % Check next dot patch
        continue
        
      end % strip or add dots
      
      % Find dots to remove or add
      j = find ( dsearch , ndiff( dp ) , 'first' ) + d1 - 1 ;
      
      % Switch their identity ...
      live( j ) = cohswitch ;
      
      % ... and adjust their lifetime
      stimtd.lifetime( j ) = newlife( 1 : numel( j ) ) ;
      
    end % adjust number of coherent dots
    
    % Check whether this is the first frame
    if  stimtd.frame1
      
      % Add one more frame to the lifetime of coherent dots
      stimtd.lifetime( live ) = stimtd.lifetime( live ) + 1 ;
      
      % And lower the flag
      stimtd.frame1( 1 ) = false ;
      
    end % handle first frame
    
    % Set which dots are coherent on the next frame
    stimtd.coh( : ) = live ;
    
    % Find coherent dots that will fall off the edge of the aperture
    wrap = find ( stimtd.coh & ~far ) ;
    nwrap = numel ( wrap ) ;
    
    % Give these dots a random y-axis location ...
    stimtd.rawxy( Y , wrap ) = 2 * par.radius * rand( 1 , nwrap ) - ...
      par.radius ;
    
    % ... plant them onto the other edge of the aperture ...
    stimtd.rawxy( X , wrap ) = ...
      -sqrt ( par.radius ^ 2 - stimtd.rawxy( Y , wrap ) .^ 2 ) ;
    
    % ... and nudge them just off the edge so that one frame's worth of
    % travel will bring them in by some random fraction of a step
    stimtd.rawxy( X , wrap ) = stimtd.rawxy( X , wrap ) - ...
      stimtd.motion * rand( 1 , nwrap ) ;

  end % coherent dot handling
  
  % Update coherent dot positions
  i = stimtd.coh ;
  stimtd.rawxy( X , i ) = stimtd.rawxy( X , i ) + stimtd.motion ;
  
  % Update coherent dot lifetimes
  stimtd.lifetime( i ) = stimtd.lifetime( i ) - 1 ;
  
  % Sample noise dot positions
  i = ~i ;
  [ stimtd.rawxy( X , i ) , stimtd.rawxy( Y , i ) ] = ...
    rndxy ( par.radius , sum ( i ) ) ;
  
  
  %%% Draw dots %%%
  
  % Set appropriate alpha blending for correct anti-aliasing of dots
  Screen( 'BlendFunction' , stimtd.ptr , ...
    GL_SRC_ALPHA , GL_ONE_MINUS_SRC_ALPHA ) ;
  
  % Apply rotation around raw coordinates origin, then apply translation
  % into absolute screen coordinates, and draw
  Screen ( 'DrawDots' , ...
           stimtd.ptr , ...
           stimtd.rotation * stimtd.rawxy + stimtd.translation , ...
           par.width , ...
           stimtd.colour , ...
           [] , ...
           2 ) ;
  
  
end % fdraw


function s = fchecksum( stimtd )
  
  % Return the sum of all coordinates. Specifically, if X and Y are N
  % element vectors such that ( X(i) , Y(i) ) is the raw coordinate of the
  % ith dot, then the check sum proceeds dot by dot, adding the X then Y
  % component:
  %
  %   S = X(1) + Y(1) + X(2) + Y(2) + ... X(N) + Y(N)
  %
  % Although addition is commutative, this is discrete arithmetic on a
  % finite precision computer. The order in which elements are summed will
  % matter.
  
  s = sum ( stimtd.rawxy( : ) ) ;
  
end % fchecksum


function ftrialclose( ~ , ~ )
  
  % Only Matlab memory was used. There is nothing to free, manually.
  
end % ftrialclose


%%% Subroutines %%%

function  f = rndlifetime ( n , p )
  
  f = ceil( log( rand( n , 1 ) ) / log( 1 - p ) ) ;
  
end % randframes


function  [ x , y ] = rndxy ( r , n )
  
  % Convert from real number on [0,1] into angle ...
  theta = 2 * pi * rand( 1 , n ) ;
  
  % ... and radius
  radius = r * sqrt( rand( 1 , n ) ) ;
    
  % Polar to cartesian coordinates
  [ x , y ] = pol2cart ( theta , radius ) ;
  
end % randdotxy


function  s = updatepar ( s )
  
  % Current parameter set
  p = s.pset( s.p ) ;
  
  %-- Survival probability , raw motion vector , rotation matrix --%
  
  % Probability of survival. Used to sample a geometric distribution for
  % coherent dot lifetimes
  s.sprob( 1 ) = 1 / ( p.avglife / s.flipinterval ) ;
  
  % Raw motion vector. Always speed * [ 1 , 0 ], so we drop y-axis
  % component and just find the number of pixels traversed in one
  % inter-frame interval.
  s.motion( 1 ) = p.speed * s.flipinterval ;
  
  % Rotation matrix
  s.rotation( : , : ) = [ +cos( p.direction ) , -sin( p.direction ) ;
                          +sin( p.direction ) , +cos( p.direction ) ] ;
  
  %-- Translation matrix --%
  
	% Translation of the formation circle
  ftrans = s.origin( : ) + p.fcentre( : ) ;
  
  % Find polar coordinates of the dot patches relative to the centre of the
  % formation circle
  
  % Indeces of dot patches. Subtract 1 so that the very first dot patch
  % rests on the x-axis with respect to the centre of the formation circle.
  dpi = ( s.fp : s.lp ) - 1 ;
  
  % angles
  a = 2 * pi / s.N * -dpi + p.frotation ;
  
  % radii
  r = p.fradius * ones( size ( dpi ) ) ;
  
  % Cartesian coordinates
  [ x , y ] = pol2cart ( a , r ) ;
  
  % The centre of each dot patch on the screen
  pcent = [ x + ftrans( 1 ) ; y + ftrans( 2 ) ] ;
  
  % Pack into cell array
  C = num2cell ( pcent , 1 ) ;
  
  % Number of repetitions
  R = repmat ( { [ 1 , s.dpp ] } , size ( dpi ) ) ;
  
  % Translation
  s.translation( : , : ) = ...
    cell2mat ( cellfun ( @repmat , C , R , 'UniformOutput' , false ) ) ;
  
  %-- Colour matrix --%
  
  % Set values to 1
  s.colour( : ) = 1 ;
  
  % Check for all black or all white flags
  if p.contrast < 0
    
    switch p.contrast
      
      % white
      case  -1 , s.colour( : ) = s.colour( : ) * s.white ;
        
      % black
      case  -2 , s.colour( : ) = s.colour( : ) * s.black ;
        
    end
    
    % all done
    return
    
  % otherwise set to background intensity
  else
    
    s.colour( : , : ) = repmat ( s.background( : ) , 1 , s.nd ) ;
    
  end % all black or white
  
  % Mixed dark and light dots. First, find out the distance of the
  % background intensity to black or white, and take the minimum.
  c = min ( ...
    [ s.white - s.background( : ) , s.background( : ) - s.black ] , ...
    [] , 2 ) ;
  
  % Weigh this by the amount of relative contrast
  c = c * p.contrast ;
  
  % Add to half the dots, and subtract from half the others
  s.colour( : , : ) = s.colour + c * ( 2 * mod ( 1 : s.nd , 2 ) - 1 ) ;
  
  
  %-- Define hit boxes --%
  
  % Centre square hit boxes that are 2 * radius wide onto the dot patches
  s.hitbox( : , : ) = [ -1 ; -1 ; 1 ; 1 ] * repmat( p.radius , 1 , s.np ) ;
  
  % Adjust x-axis position
  s.hitbox( [ 1 , 3 ] , : ) = ...
    s.hitbox( [ 1 , 3 ] , : ) + pcent( [ 1 , 1 ] , : ) ;
  
  % Adjust y-axis position
  s.hitbox( [ 2 , 4 ] , : ) = ...
    s.hitbox( [ 2 , 4 ] , : ) + pcent( [ 2 , 2 ] , : ) ;
  
end % updatepar

